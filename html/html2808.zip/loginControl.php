<?php
require('model.php');
$vercode =$_REQUEST['verCode'];
// echo $vercode;   
getClient2($vercode);

?>